let id = fun x -> x in
id 2