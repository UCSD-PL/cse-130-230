let l = [5;6;7;8] in
if null l then 0 else 1