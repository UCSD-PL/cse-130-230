let f = fun x -> fun y -> fun a ->  a x*y in
let g = fun x -> x+1*3 in
f 7 8 g
