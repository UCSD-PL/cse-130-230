let x = 1 in
let y = 2 in
let z = x + y in
let x = x + z in
x + y
